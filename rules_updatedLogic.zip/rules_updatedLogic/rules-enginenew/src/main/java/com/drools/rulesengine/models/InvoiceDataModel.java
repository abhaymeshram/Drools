package com.drools.rulesengine.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InvoiceDataModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private List<Invoice> invoices = new ArrayList<Invoice>();
    private Invoice invoice;
    private LDC ldc;
    private List<Advance> advances;
    private Provision provision;
    private double tdcRate;
    private boolean advanceItemMatched;
    private List<Double> tds = new LinkedList<Double>();

    public List<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public LDC getLdc() {
        return ldc;
    }

    public void setLdc(LDC ldc) {
        this.ldc = ldc;
    }

    public List<Advance> getAdvances() {
        return advances;
    }

    public void setAdvances(List<Advance> advances) {
        this.advances = advances;
    }

    public Provision getProvision() {
        return provision;
    }

    public void setProvision(Provision provision) {
        this.provision = provision;
    }

    public double getTdcRate() {
        return tdcRate;
    }

    public void setTdcRate(double tdcRate) {
        this.tdcRate = tdcRate;
    }

    public boolean isAdvanceItemMatched() {
        return advanceItemMatched;
    }

    public void setAdvanceItemMatched(boolean advanceItemMatched) {
        this.advanceItemMatched = advanceItemMatched;
    }

    public List<Double> getTds() {
        return tds;
    }

    public void setTds(List<Double> tds) {
        this.tds = tds;
    }

    @Override
    public String toString() {
        return "InvoiceDataModel [invoices=" + invoices + ", invoice=" + invoice + ", ldc=" + ldc + ", advances="
                + advances + ", provision=" + provision + ", tdcRate=" + tdcRate + ", advanceItemMatched="
                + advanceItemMatched + ", tds=" + tds + "]";
    }

    public void splitInvoices(final List<Double> totalTds) {
        try {
            Invoice invoiceLdc1 = this.invoice.clone();
            invoiceLdc1.setInvoice_line_item_tds_amount(totalTds.get(0));
            invoiceLdc1.setInvoice_line_item_tds_rate(this.ldc.getLdc_final_tds_rate());
            Invoice invoiceLdc2 = this.invoice.clone();
            invoiceLdc2.setInvoice_line_item_tds_amount(totalTds.get(1));
            invoices.add(invoiceLdc1);
            invoices.add(invoiceLdc2);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

    }

    public static boolean isAdvanceDeducteeAndAdvanceSection(InvoiceDataModel invoiceDataModel) {
        if (invoiceDataModel == null || invoiceDataModel.getAdvances() != null || invoiceDataModel.getAdvances().size() == 0 || invoiceDataModel.getInvoice() == null || invoiceDataModel.getInvoices() == null || invoiceDataModel.getInvoices().size() == 0)
            return false;
        boolean isAdvanaceMatched = false;
        for (Invoice invoice : invoiceDataModel.getInvoices()) {
            for (Advance advance : invoiceDataModel.getAdvances()) {
                if (advance.getAdvance_deductee_pan() != null
                        && advance.getAdvance_deductee_pan()
                        .equalsIgnoreCase(invoice.getInvoice_advance_deductee_pan())
                        && advance.getAdvance_section() != null && advance.getAdvance_section().equalsIgnoreCase(
                        invoice.getInvoice_line_item_actual_tds_section())) {
                    if (advance.getAdvance_amount() == invoice.getInvoice_line_item_tds_amount()) {
                        invoice.setAdvanceMatched(Boolean.TRUE);
                        isAdvanaceMatched = true;
                        break;
                    } else if (advance.getAdvance_amount() < invoice.getInvoice_line_item_tds_amount()) {
                        try {
                            Invoice invoiceLdc1 = invoice.clone();
                            invoiceLdc1.setInvoice_line_item_tds_amount(advance.getAdvance_amount());
                            invoiceLdc1.setAdvanceMatched(Boolean.TRUE);
                            Invoice invoiceLdc2 = invoice.clone();
                            invoiceLdc2.setInvoice_line_item_tds_amount(invoice.getInvoice_line_item_tds_amount() - advance.getAdvance_amount());
                            invoiceDataModel.getInvoices().add(invoiceLdc1);
                            invoiceDataModel.getInvoices().add(invoiceLdc2);
                            isAdvanaceMatched = true;
                            break;
                        } catch (CloneNotSupportedException e) {
                            e.printStackTrace();
                        }
                    }
                    System.out.println("Advance Amount: " + advance);
                }
            }
            if (isAdvanaceMatched)
                break;
        }
        return true;
    }

}

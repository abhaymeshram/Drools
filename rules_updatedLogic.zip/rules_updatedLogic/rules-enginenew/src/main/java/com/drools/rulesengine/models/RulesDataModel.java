package com.drools.rulesengine.models;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RulesDataModel implements Serializable {
	private static final Logger logger = LoggerFactory.getLogger(RulesDataModel.class);

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<String> modules;
	private String deductee_pan;
	private String deductor_tan;
	private String name_of_the_deductee;
	private String actions;
	private List<String> invoiceGlRecordCheck;
	private String matchedRulesList;
	private String nonresident_deductee_indicator;
	private String migo_number;
	private String miro_number;
	private String erp_document_number;
	private String provisions_process;
	private String provisions_process_option;
	private String tds_section;
	private String po_number;
	private String po_date;
	private String deductee_tin;
	

	public String getDeductee_tin() {
		return deductee_tin;
	}

	public void setDeductee_tin(String deductee_tin) {
		this.deductee_tin = deductee_tin;
	}

	public List<String> getModules() {
		return modules;
	}

	public void setModules(List<String> modules) {
		this.modules = modules;
	}

	public String getDeductee_pan() {
		return deductee_pan;
	}

	public void setDeductee_pan(String deductee_pan) {
		this.deductee_pan = deductee_pan;
	}

	public String getDeductor_tan() {
		return deductor_tan;
	}

	public void setDeductor_tan(String deductor_tan) {
		this.deductor_tan = deductor_tan;
	}

	public String getName_of_the_deductee() {
		return name_of_the_deductee;
	}

	public void setName_of_the_deductee(String name_of_the_deductee) {
		this.name_of_the_deductee = name_of_the_deductee;
	}

	public String getActions() {
		return actions;
	}

	public void setActions(String actions) {
		this.actions = actions;
	}

	public List<String> getInvoiceGlRecordCheck() {
		return invoiceGlRecordCheck;
	}

	public void setInvoiceGlRecordCheck(List<String> invoiceGlRecordCheck) {
		this.invoiceGlRecordCheck = invoiceGlRecordCheck;
	}

	public String getMatchedRulesList() {
		return matchedRulesList;
	}

	public void setMatchedRulesList(String matchedRulesList) {
		this.matchedRulesList = matchedRulesList;
	}

	public String getNonresident_deductee_indicator() {
		return nonresident_deductee_indicator;
	}

	public void setNonresident_deductee_indicator(String nonresident_deductee_indicator) {
		this.nonresident_deductee_indicator = nonresident_deductee_indicator;
	}

	public String getMigo_number() {
		return migo_number;
	}

	public void setMigo_number(String migo_number) {
		this.migo_number = migo_number;
	}

	public String getMiro_number() {
		return miro_number;
	}

	public void setMiro_number(String miro_number) {
		this.miro_number = miro_number;
	}

	public String getErp_document_number() {
		return erp_document_number;
	}

	public void setErp_document_number(String erp_document_number) {
		this.erp_document_number = erp_document_number;
	}

	public String getProvisions_process() {
		return provisions_process;
	}

	public void setProvisions_process(String provisions_process) {
		this.provisions_process = provisions_process;
	}

	public String getProvisions_process_option() {
		return provisions_process_option;
	}

	public void setProvisions_process_option(String provisions_process_option) {
		this.provisions_process_option = provisions_process_option;
	}

	public String getTds_section() {
		return tds_section;
	}

	public void setTds_section(String tds_section) {
		this.tds_section = tds_section;
	}

	public String getPo_number() {
		return po_number;
	}

	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}

	public String getPo_date() {
		return po_date;
	}

	public void setPo_date(String po_date) {
		this.po_date = po_date;
	}

	

	@Override
	public String toString() {
		return "RulesDataModel [modules=" + modules + ", deductee_pan=" + deductee_pan + ", deductor_tan="
				+ deductor_tan + ", name_of_the_deductee=" + name_of_the_deductee + ", actions=" + actions
				+ ", invoiceGlRecordCheck=" + invoiceGlRecordCheck + ", matchedRulesList=" + matchedRulesList
				+ ", nonresident_deductee_indicator=" + nonresident_deductee_indicator + ", migo_number=" + migo_number
				+ ", miro_number=" + miro_number + ", erp_document_number=" + erp_document_number
				+ ", provisions_process=" + provisions_process + ", provisions_process_option="
				+ provisions_process_option + ", tds_section=" + tds_section + ", po_number=" + po_number + ", po_date="
				+ po_date + ", deductee_tin=" + deductee_tin + "]";
	}

	public static boolean isContains(List<String> list, String param) {
		logger.info("Checking value for {} with paramter {}", list, param);
		if (list == null || list.size() == 0 || param == null)
			return false;
		List<String> paramList = Arrays.asList(param.split(","));
		if (paramList.size() == 0 && list.contains(""))
			return Boolean.TRUE;
		for (String value : paramList) {
			if (list.contains(value))
				return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	
	public static boolean isNotContains(List<String> list, String param) {
		logger.info("Checking value for {} with paramter {}", list, param);
		if (list == null || list.size() == 0 || param == null)
			return false;
		List<String> paramList = Arrays.asList(param.split(","));
		if (paramList.size() == 0 && list.contains(""))
			return Boolean.TRUE;
		for (String value : paramList) {
			if (list.contains(value))
				return Boolean.FALSE;
		}
		return Boolean.FALSE;
	}
	
	public static boolean isBlank(String data, String param) {
		if(param != null & param.equals("Yes"))
			return data == null || data.isEmpty();
		
		if(param != null & param.equals("No"))
			return data != null && !data.isEmpty();
		
		return false;
	}

}

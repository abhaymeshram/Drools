package com.drools.rulesengine.models;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Advance implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double advance_amount;
	private String advance_deductee_pan;
	private String advance_section;

	public double getAdvance_amount() {
		return advance_amount;
	}

	public void setAdvance_amount(double advance_amount) {
		this.advance_amount = advance_amount;
	}

	public String getAdvance_deductee_pan() {
		return advance_deductee_pan;
	}

	public void setAdvance_deductee_pan(String advance_deductee_pan) {
		this.advance_deductee_pan = advance_deductee_pan;
	}

	public String getAdvance_section() {
		return advance_section;
	}

	public void setAdvance_section(String advance_section) {
		this.advance_section = advance_section;
	}

	@Override
	public String toString() {
		return "Advance [advance_amount=" + advance_amount + ", advance_deductee_pan=" + advance_deductee_pan
				+ ", advance_section=" + advance_section + "]";
	}

}
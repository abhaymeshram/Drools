package com.drools.rulesengine.utils;

public interface RulesConstant {
	
	String RULEFILELOCATION         =      "rule.file.location";
	String RULEPATHCONSTANT 		= 	   "src/main/resources/";

}

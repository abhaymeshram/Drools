package com.drools.rulesengine.service.impl;

import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.drools.rulesengine.models.InvoiceDataModel;
import com.drools.rulesengine.models.RulesDataModel;
import com.drools.rulesengine.service.RuleService;
import com.drools.rulesengine.utils.RulesConstant;
import com.drools.rulesengine.utils.RulesUtils;
import com.drools.rulesengine.utils.TrackingAgendaEventListener;

@Service
public class RuleServiceImpl implements RuleService {
	
	private static final Logger logger = LoggerFactory.getLogger(RuleServiceImpl.class);
	
	@Autowired
	private Environment env;

	@Override
	public RulesDataModel applyRules(RulesDataModel rulesDataModel) throws Exception {
		logger.info("In applyRules, applying rules for data object:  " + rulesDataModel);
		KieSession kSession;
		try {
			kSession = RulesUtils.createKession(env.getProperty(RulesConstant.RULEFILELOCATION));
			if (kSession != null && rulesDataModel != null) {
				TrackingAgendaEventListener trackingAgendaEventListener = new TrackingAgendaEventListener();
				kSession.addEventListener(trackingAgendaEventListener);
				//kSession.getAgenda().getAgendaGroup("RULEFLOW-GROUP").setFocus();
				kSession.insert(rulesDataModel);
				kSession.fireAllRules();
				kSession.dispose();
				rulesDataModel.setMatchedRulesList(trackingAgendaEventListener.matchsToString());
				logger.info("Rules applied successfully. Update data object:  " + rulesDataModel);
				return rulesDataModel;
			}
			}catch(Exception exception) {
				exception.printStackTrace();
				throw exception;

			}
		return rulesDataModel;
	}
	
	
	@Override
	public InvoiceDataModel applyInvoiceRules(InvoiceDataModel invoiceDataModel) throws Exception {
		logger.info("In applyRules, applying rules for data object:  " + invoiceDataModel);
		KieSession kSession;
		try {
			kSession = RulesUtils.createKession(env.getProperty(RulesConstant.RULEFILELOCATION));
			if (kSession != null && invoiceDataModel != null) {
				TrackingAgendaEventListener trackingAgendaEventListener = new TrackingAgendaEventListener();
				kSession.addEventListener(trackingAgendaEventListener);
			//	kSession.getAgenda().getAgendaGroup("INVOICE").setFocus();
				//kSession.getAgenda().getAgendaGroup("RULES").setFocus();
				kSession.insert(invoiceDataModel);
				kSession.fireAllRules();
				kSession.dispose();
//				rulesDataModel.setMatchedRulesList(trackingAgendaEventListener.matchsToString());
				logger.info("Rules applied successfully. Update data object:  " + invoiceDataModel);
				return invoiceDataModel;
			}
			}catch(Exception exception) {
				exception.printStackTrace();
				throw exception;

			}
		return invoiceDataModel;
	}

	@Override
	public String updateRules() throws Exception {
		RulesUtils.initialize(env.getProperty(RulesConstant.RULEFILELOCATION));
		logger.info("Rules updated successfully.");
		return "Rules updated Successfully!";
	}

}

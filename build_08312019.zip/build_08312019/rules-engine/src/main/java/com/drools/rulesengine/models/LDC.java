package com.drools.rulesengine.models;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LDC implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double ldc_master_total_amount ;
	private double ldc_final_tds_rate;
	
	public double getLdc_master_total_amount() {
		return ldc_master_total_amount;
	}
	public void setLdc_master_total_amount(double ldc_master_total_amount) {
		this.ldc_master_total_amount = ldc_master_total_amount;
	}
	public double getLdc_final_tds_rate() {
		return ldc_final_tds_rate;
	}
	public void setLdc_final_tds_rate(double ldc_final_tds_rate) {
		this.ldc_final_tds_rate = ldc_final_tds_rate;
	}
	
	@Override
	public String toString() {
		return "LDC [ldc_master_total_amount=" + ldc_master_total_amount + ", ldc_final_tds_rate=" + ldc_final_tds_rate
				+ "]";
	}

	
	// Getter Methods

}